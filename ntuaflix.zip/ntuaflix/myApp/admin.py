from django.contrib import admin
from .models import Names, Movies, Crews, Episode, Ratings, Akas, Principals

admin.site.register(Names)
admin.site.register(Movies)
admin.site.register(Crews)
admin.site.register(Episode)
admin.site.register(Ratings)
admin.site.register(Akas)
admin.site.register(Principals)
# Register your models here.
